# flutter-login-template
Template project for creating flutter apps with integration with Firebase based on [Flutter Flat App Firebase](https://github.com/GeekyAnts/FlatApp-Firebase-Flutter)

## How-to
To use this repository correctly, just configure firebase placing your google-services.json into [app folder](/android/app/)



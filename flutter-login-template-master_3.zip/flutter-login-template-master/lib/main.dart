import 'package:verboshop/Routes.dart';

void main() {
  new Routes();
}

import 'package:flutter/material.dart';


DecorationImage backgroundImage = new DecorationImage(
  image: new ExactAssetImage('assets/login-screen-background.png'),
  fit: BoxFit.cover,
);

ExactAssetImage logo = new ExactAssetImage("assets/vsdove.png");




import 'package:flutter/material.dart';

/// https://www.reddit.com/r/FlutterDev/comments/d51o4w/were_the_flutter_team_at_google_ask_us_anything/f0t8ghn?utm_source=share&utm_medium=web2x
class NullWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) => SizedBox.shrink();
}

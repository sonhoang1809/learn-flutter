// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'promotion_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PromotionItem _$PromotionItemFromJson(Map<String, dynamic> json) {
  return PromotionItem(json['id'] as String, json['image'] as String);
}

Map<String, dynamic> _$PromotionItemToJson(PromotionItem instance) =>
    <String, dynamic>{'id': instance.id, 'image': instance.promotion_image};

bool get isDebug {
  bool inDebugMode = false;
  assert(inDebugMode = true);
  return inDebugMode;
}

class AppUtils {
  //Check if debug mode

}

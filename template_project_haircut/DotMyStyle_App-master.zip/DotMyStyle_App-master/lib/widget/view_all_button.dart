import 'package:flutter/material.dart';

class ViewAll extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Text(
      "VIEW ALL",
      style: TextStyle(fontWeight: FontWeight.w700, letterSpacing: 1.2, color: Colors.red, fontSize: 12.0),
    );
  }
}
